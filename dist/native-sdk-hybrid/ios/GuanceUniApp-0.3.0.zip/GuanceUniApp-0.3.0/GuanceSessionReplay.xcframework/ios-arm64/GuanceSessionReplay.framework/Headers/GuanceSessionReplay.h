//  Copyright 2026 Shanghai Guance Information Technology Co., Ltd.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

#ifndef GuanceSessionReplay_h
#define GuanceSessionReplay_h

#import <Foundation/Foundation.h>

//! Project version number for GuanceSessionReplay.
FOUNDATION_EXPORT double GuanceSessionReplayVersionNumber;

//! Project version string for GuanceSessionReplay.
FOUNDATION_EXPORT const unsigned char GuanceSessionReplayVersionString[];

#import "FTSessionReplay.h"
#import "NSView+FTSRPrivacy.h"
#import "UIView+FTSRPrivacy.h"

#endif /* GuanceSessionReplay_h */
