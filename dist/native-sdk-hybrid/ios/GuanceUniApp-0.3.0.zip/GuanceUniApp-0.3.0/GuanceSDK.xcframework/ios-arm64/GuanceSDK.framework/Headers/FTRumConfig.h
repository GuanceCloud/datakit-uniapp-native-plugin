//
//  FTRumConfig.h
//
//  Created by hulilei on 2025/7/22.
//  Copyright 2025 Shanghai Guance Information Technology Co., Ltd.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

#import <Foundation/Foundation.h>

/// Crash monitoring type
typedef NS_OPTIONS(NSUInteger, FTCrashMonitorType){
    /** Monitor Mach kernel exceptions. */
    FTCrashMonitorTypeMachException      = 0x01,
    
    /** Monitor fatal signals. */
    FTCrashMonitorTypeSignal             = 0x02,
    
    /** Monitor uncaught C++ exceptions. */
    FTCrashMonitorTypeCPPException       = 0x04,
    
    /** Monitor uncaught Objective-C NSExceptions. */
    FTCrashMonitorTypeNSException        = 0x08,
    
    /** Track and inject system information. */
    FTCrashMonitorTypeSystem             = 0x40,
    
    /** Track and inject application state information. */
    FTCrashMonitorTypeApplicationState   = 0x80,
    
};

/// Bitmask that enables all supported crash monitors.
#define FTCrashMonitorTypeAll                                                                  \
    (FTCrashMonitorTypeMachException | FTCrashMonitorTypeSignal                            \
        | FTCrashMonitorTypeCPPException | FTCrashMonitorTypeNSException                   \
        | FTCrashMonitorTypeApplicationState | FTCrashMonitorTypeSystem)


/// Bitmask that enables all crash monitors except Mach exceptions for broader device compatibility.
#define FTCrashMonitorTypeHighCompatibility                                                          \
    (FTCrashMonitorTypeAll & (~FTCrashMonitorTypeMachException))
/// Device information in ERROR
typedef NS_OPTIONS(NSUInteger, FTErrorMonitorType) {
    /// Enable all monitoring: battery, memory, CPU usage
    FTErrorMonitorAll          = 0xFFFFFFFF,
    /// Battery level
    FTErrorMonitorBattery      = 1 << 1,
    /// Total memory, memory usage
    FTErrorMonitorMemory       = 1 << 2,
    /// CPU usage
    FTErrorMonitorCpu          = 1 << 3,
};

/// Device information monitoring items
typedef NS_OPTIONS(NSUInteger, FTDeviceMetricsMonitorType){
    /// Enable all monitoring items: memory, CPU, FPS
    FTDeviceMetricsMonitorAll      = 0xFFFFFFFF,
    /// Average memory, peak memory
    FTDeviceMetricsMonitorMemory   = 1 << 2,
    /// CPU maximum fluctuation, average
    FTDeviceMetricsMonitorCpu      = 1 << 3,
    /// FPS minimum frame rate, average frame rate
    FTDeviceMetricsMonitorFps API_UNAVAILABLE(macos) = 1 << 4,
};
/// Monitoring item sampling frequency
typedef NS_ENUM(NSUInteger, FTMonitorFrequency) {
    /// 500ms (default)
    FTMonitorFrequencyDefault,
    /// 100ms
    FTMonitorFrequencyFrequent,
    /// 1000ms
    FTMonitorFrequencyRare,
};

/// RUM discard strategy
typedef NS_ENUM(NSInteger, FTRUMCacheDiscard)  {
    /// Default, when log data count exceeds maximum (100_000), new data is not written
    FTRUMDiscard,
    /// When log data exceeds maximum, discard old data
    FTRUMDiscardOldest
};

#import "FTActionTrackingHandler.h"
#import "FTViewTrackingHandler.h"
#import "FTIssueDataProvider.h"

NS_ASSUME_NONNULL_BEGIN
/// RUM filter resource callback, returns: NO means to collect, YES means not to collect.
typedef BOOL(^FTResourceUrlHandler)(NSURL * url);
/// RUM Resource custom add extra properties
typedef NSDictionary<NSString *,id>* _Nullable (^FTResourcePropertyProvider)( NSURLRequest * _Nullable request, NSURLResponse * _Nullable response,NSData *_Nullable data, NSError *_Nullable error);
/// Support custom intercept `URLSessionTask` Error, confirm interception returns YES, not intercepted returns NO
typedef BOOL (^FTSessionTaskErrorFilter)(NSError *_Nonnull error);



/// RUM functionality configuration items
@interface FTRumConfig : NSObject
/// Designated initializer, set appid
///
/// - Parameters:
///   - appid: User access monitoring application ID unique identifier, automatically generated when creating monitoring in the user access monitoring console.
/// - Returns: rum configuration items.
- (instancetype)initWithAppid:(nonnull NSString *)appid;
/// Disable new initialization
+ (instancetype)new NS_UNAVAILABLE;
/// User access monitoring application ID unique identifier, automatically generated when creating monitoring in the user access monitoring console.
@property (nonatomic, copy) NSString *appid;
/// Sampling configuration, property values: 0 to 100, 100 means 100% collection, no data sample compression.
@property (nonatomic, assign) int sampleRate;
/// Deprecated. Use `sampleRate`.
@property (nonatomic, assign) int samplerate DEPRECATED_MSG_ATTRIBUTE("Use sampleRate.");
/// Collect sessions that have errors
/// When the feature is enabled, if a Session that was not originally selected by the sampling rate encounters an error, the SDK will collect data from these originally uncollected Sessions
@property (nonatomic, assign) int sessionOnErrorSampleRate;
/// Set whether to track user actions, currently supports app launch and click actions,
/// Only effective when View events are present
@property (nonatomic, assign) BOOL enableTraceUserAction;
/// Set whether to track page lifecycle (only applies to autotrack)
@property (nonatomic, assign) BOOL enableTraceUserView;
/// Set whether to track user network requests (only applies to native http)
@property (nonatomic, assign) BOOL enableTraceUserResource;
/// Set whether to collect network request Host IP (only applies to native http, iOS 13 and above)
@property (nonatomic, assign) BOOL enableResourceHostIP;
/// Custom collection resource rules.
/// Determine whether to collect corresponding resource data based on the requested resource URL, default is to collect all. Returns: NO means to collect, YES means not to collect.
@property (nonatomic, copy, nullable) FTResourceUrlHandler resourceUrlHandler;
/// Set whether to collect crash logs
@property (nonatomic, assign) BOOL enableTrackAppCrash;
/// Crash monitoring type, default:FTCrashMonitorTypeHighCompatibility
/// Note: Required are FTCrashMonitorTypeSystem | FTCrashMonitorTypeApplicationState (provides important information for crash reports)
@property (nonatomic, assign) FTCrashMonitorType crashMonitoring;
/// Set whether to collect freezes
@property (nonatomic, assign) BOOL enableTrackAppFreeze;
/// Set freeze threshold. Unit milliseconds 100 < freezeDurationMs, default 250ms
@property (nonatomic, assign) long freezeDurationMs;
/// Set whether to collect ANR
///
/// runloop collects main thread freezes
@property (nonatomic, assign) BOOL enableTrackAppANR;
/// Synchronously supplies validated custom fields for automatically collected
/// Crash and ANR RUM Errors.
///
/// This callback may run concurrently, reentrantly, and on a non-main SDK
/// processing thread. Keep it thread-safe and fast, and do not perform UI,
/// network, disk, dispatch waits, or long lock waits.
@property (nonatomic, copy, nullable) FTIssueDataProvider issueDataProvider;
/// Device information in ERROR
@property (nonatomic, assign) FTErrorMonitorType errorMonitorType;
/// Set monitoring type, if not set then monitoring is not enabled
@property (nonatomic, assign) FTDeviceMetricsMonitorType deviceMetricsMonitorType;
/// Set monitoring sampling frequency
@property (nonatomic, assign) FTMonitorFrequency monitorFrequency;
/// Set rum global tags
///
/// Reserved tags: special key - track_id (for tracking functionality)
@property (nonatomic, copy, nullable) NSDictionary<NSString*,NSString*> *globalContext;
/// RUM maximum cache limit, default 100_000
@property (nonatomic, assign) int rumCacheLimitCount;
/// RUM discard strategy
@property (nonatomic, assign) FTRUMCacheDiscard rumDiscardType;
/// Adds custom properties to RUM resource events.
/// The callback receives the request, response, optional buffered response body data, and error.
/// Response body data is not guaranteed: when the SDK buffers delegate response chunks, media responses and non-media responses larger than 512 KB are not cached and pass nil.
@property (nonatomic, copy, nullable) FTResourcePropertyProvider resourcePropertyProvider;
/// Intercept SessionTask Error, confirm interception returns YES, not intercepted returns NO
@property (nonatomic, copy, nullable) FTSessionTaskErrorFilter sessionTaskErrorFilter;

/// Set whether to enable WebView data collection, default YES
@property (nonatomic, assign) BOOL enableTraceWebView;
/// Set specific hosts or domains allowed to collect WebView data, nil means collect all.
@property (nonatomic, copy, nullable) NSArray *allowWebViewHost;

/// A handler for user-defined collection of `ViewControllers` as RUM views for tracking.
/// It takes effect when enableTraceUserView = YES.
/// RUM will call this callback for each `ViewController` presented in the application.
///  - If the given controller needs to start a RUM view, return the FTRUMView parameters;
///  - Return nil to ignore it.
@property (nonatomic, strong, nullable) FTViewTrackingHandler viewTrackingHandler API_UNAVAILABLE(macos);

/// Experimental: A handler for user-defined collection of automatically extracted SwiftUI View names as RUM views.
/// Set this only when your app needs automatic SwiftUI View tracking.
/// If you do not need custom filtering or naming, set `FTDefaultSwiftUIViewTrackingHandler`.
/// It takes effect when enableTraceUserView = YES and this handler is not nil.
/// This experimental API may change in future releases.
/// RUM will call this callback when a SwiftUI view name is extracted from a hosting view controller.
///  - If the given SwiftUI view name needs to start a RUM view, return the FTRUMView parameters;
///  - Return nil to ignore it.
@property (nonatomic, strong, nullable) id<FTSwiftUIViewTrackingHandler> swiftUIViewTrackingHandler API_UNAVAILABLE(macos);

/// The handler deciding if a given RUM Action should be recorded.
/// It takes effect when enableTraceUserAction = YES.
///  - If need to Start a RUM action, return the FTRUMAction parameters;
///  - Return nil to ignore it.
@property (nonatomic, strong, nullable) FTActionTrackingHandler actionTrackingHandler API_UNAVAILABLE(macos);

/// Enable freeze collection and set freeze threshold.
/// - Parameter enableTrackAppFreeze: Set whether to collect freezes
/// - Parameter freezeDurationMs: Freeze threshold, unit milliseconds 100 < freezeDurationMs, default 250ms
-(void)setEnableTrackAppFreeze:(BOOL)enableTrackAppFreeze freezeDurationMs:(long)freezeDurationMs;
@end
NS_ASSUME_NONNULL_END
