//
//  FTDefaultUIKitViewTrackingHandler.h
//  FTMobileSDK
//
//  Created by hulilei on 2025/8/6.
//  Copyright 2025 Shanghai Guance Information Technology Co., Ltd.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

#import <Foundation/Foundation.h>
#import <TargetConditionals.h>
#if TARGET_OS_IOS || TARGET_OS_TV
#import "FTViewTrackingHandler.h"

NS_ASSUME_NONNULL_BEGIN
/// Default handler that creates RUM views for automatically tracked UIKit view controllers.
@interface FTDefaultUIKitViewTrackingHandler : NSObject<FTUIKitViewTrackingHandler>

@end

/// Default handler that creates RUM views from automatically extracted SwiftUI view names.
@interface FTDefaultSwiftUIViewTrackingHandler : NSObject<FTSwiftUIViewTrackingHandler>
@end
NS_ASSUME_NONNULL_END
#endif
